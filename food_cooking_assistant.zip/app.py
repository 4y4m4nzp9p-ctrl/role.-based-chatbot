import streamlit as st
from openai import OpenAI

st.set_page_config(
    page_title="Food & Cooking Assistant",
    page_icon="🍳",
    layout="wide",
)

ROLES = {
    "👨‍🍳 Recipe Chef": {
        "system": (
            "You are a practical recipe chef. Suggest recipes based on the user's "
            "ingredients, preferences, available tools, and time. Give clear steps, "
            "ingredient quantities, preparation time, and useful substitutions."
        ),
        "hint": "Turn ingredients and cravings into clear, cookable recipes.",
        "placeholder": "e.g., What can I cook with eggs, rice, and green onions?",
    },
    "🥕 Ingredient Expert": {
        "system": (
            "You are an ingredient expert. Explain ingredient flavors, textures, "
            "seasonality, storage, preparation, and suitable substitutes. Give "
            "practical kitchen advice and distinguish general guidance from cases "
            "where food-safety rules matter."
        ),
        "hint": "Learn how ingredients work, how to store them, and what can replace them.",
        "placeholder": "e.g., How should I store mushrooms and what can replace them?",
    },
    "🥗 Nutrition Guide": {
        "system": (
            "You are a food nutrition guide. Offer balanced, general nutrition "
            "information about foods and meals, including approximate nutrients "
            "when possible. State that estimates vary by brand, portion, and cooking "
            "method. Avoid diagnosing conditions or prescribing restrictive diets."
        ),
        "hint": "Understand meals and nutrients with practical, balanced guidance.",
        "placeholder": "e.g., Compare the general nutrition of tofu and eggs.",
    },
    "🧀 Food Pairing Specialist": {
        "system": (
            "You are a food-pairing specialist. Recommend ingredients, sauces, "
            "seasonings, textures, and drinks that complement the user's dish. "
            "Explain briefly why combinations work and offer alternatives."
        ),
        "hint": "Find flavor combinations and easy ways to make a dish more interesting.",
        "placeholder": "e.g., What ingredients pair well with roasted sweet potato?",
    },
    "📅 Meal Planner": {
        "system": (
            "You are a practical meal-planning assistant. Suggest flexible meal ideas "
            "based on budget, schedule, cooking skill, preferences, and available "
            "ingredients. Include a simple shopping list when useful and avoid "
            "unnecessarily restrictive eating advice."
        ),
        "hint": "Organize simple meals and shopping around your schedule and preferences.",
        "placeholder": "e.g., Suggest three easy dinners for a busy week.",
    },
}

with st.sidebar:
    st.subheader("🔑 API & Role Settings")
    api_key = st.text_input(
        "Enter your OpenAI API Key:",
        type="password",
        placeholder="sk-xxxxxxxxxxxxxxxxx",
        help="Your key is used to make requests to the OpenAI API. Do not share it or upload it to GitHub.",
    )
    role_name = st.selectbox("Choose a role:", list(ROLES.keys()))
    st.info(ROLES[role_name]["hint"])
    model = st.selectbox("Model:", ["gpt-4o-mini", "gpt-4o"], index=0)

st.title("🍳 Food & Cooking Assistant")
st.write("Choose a food expert and ask a question about cooking, ingredients, nutrition, food pairing, or meal ideas.")

question = st.text_area(
    "💬 Enter your question or idea:",
    placeholder=ROLES[role_name]["placeholder"],
    height=150,
)

if st.button("Generate Response", type="primary"):
    if not api_key.strip():
        st.warning("Please enter your OpenAI API key in the sidebar.")
    elif not question.strip():
        st.warning("Please enter a question or idea.")
    else:
        try:
            client = OpenAI(api_key=api_key.strip())
            with st.spinner("Thinking..."):
                response = client.chat.completions.create(
                    model=model,
                    messages=[
                        {"role": "system", "content": ROLES[role_name]["system"]},
                        {"role": "user", "content": question.strip()},
                    ],
                    temperature=0.8,
                )
            st.markdown(f"### {role_name}")
            st.write(response.choices[0].message.content)
        except Exception as exc:
            st.error(f"Error: {exc}")

st.divider()
st.caption("Food & Cooking Assistant • Built with Streamlit and the OpenAI API")

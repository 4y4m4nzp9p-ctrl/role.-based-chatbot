# Food & Cooking Assistant

A role-based food and cooking chatbot built with Streamlit and the OpenAI API.

## Expert roles
- **Recipe Chef** — recipes, quantities, steps, and substitutions
- **Ingredient Expert** — ingredient details, storage, preparation, and substitutes
- **Nutrition Guide** — general nutrition information and approximate nutrient comparisons
- **Food Pairing Specialist** — flavor combinations, sauces, and seasonings
- **Meal Planner** — flexible meal ideas and shopping lists

## Run locally

1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

4. Start the app:

   ```bash
   streamlit run app.py
   ```

5. Enter your OpenAI API key in the sidebar.

## Deploy with GitHub and Streamlit Community Cloud

1. Create a GitHub repository.
2. Upload `app.py`, `requirements.txt`, and `README.md`.
3. Open Streamlit Community Cloud and create a new app from that repository.
4. Set the main file path to `app.py` and deploy.

## Security note

Do not commit your API key to GitHub. Enter it in the app sidebar when using the app. API usage may incur charges depending on your OpenAI account and model.
